public class DropDeadlinePassed extends Exception {
    public DropDeadlinePassed(String message) {
        super(message);
    }
}

