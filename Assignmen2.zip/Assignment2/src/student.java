import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class student extends user implements login{
    private int semester;
    public List<course> currentcourses;
    private List<course> completedcourses;
    private List<complaint> complaints;
    private final int creditl = 20;
    private int rollno;
    public Map<course, String> courseGrades;
    private Map<Integer, Double> semesterSGPA;

    private Map<course, Long> registrationTime;

    public student(String name, String email, String password, int rollno) {
        super(name, email, password);
        this.semester = 1;
        this.currentcourses = new ArrayList<>();
        this.completedcourses = new ArrayList<>();
        this.complaints = new ArrayList<>();
        this.rollno = rollno;
        this.courseGrades = new HashMap<>();
        this.semesterSGPA = new HashMap<>();
        this.registrationTime = new HashMap<>();
    }

    public void signin(String name, String email, String password) {
        System.out.println("Signing up student...");
        this.name = name;
        this.email = email;
        this.password = password;
    }



    public boolean login(String email, String password) throws InvalidLogin {
        if (this.email.equals(email) && this.password.equals(password)) {
            return true;
        } else {
            throw new InvalidLogin("Invalid email or password.");
        }
    }



    public void logout() {
        System.out.println("Student " + this.name + " logged out.");
    }

    public void viewAvailableCourses() {
        System.out.println("Available courses for registration:");

        List<course> courses = coursecatalog.getAllCourses();
        System.out.println("Courses available for current semester (" + semester + "):");
        System.out.println();


        for (course c : courses) {
            if (c.getSemester() <= this.semester && c.getSemester() % 2 == this.semester % 2) {
                System.out.println("__________________");
                System.out.println(c.toString());
                System.out.println("__________________");
            }
        }
    }

    public void viewSchedule() {
        System.out.println("Weekly Schedule for Semester " + semester + ":");
        for (course c : currentcourses) {
            if (c != null) {
                System.out.println("Course Code: " + c.getcode() + ", Title: " + c.getTitle());
                c.printschedule();
            } else {
                System.out.println("No schedule available.");
            }
            System.out.println();
        }
    }


    public boolean registerCourse(String courseCode) {
        course c = coursecatalog.findCourseByCode(courseCode);

        if (c == null) {
            System.out.println("Course with code " + courseCode + " not found.");
            return false;
        }

        if (currentcourses.contains(c)) {
            System.out.println("You are already registered for this course.");
            return false;
        }

        if (c.getSemester() == this.semester) {
        } else if (c.getSemester() < this.semester) {
            int currentsemval = this.semester % 2; // 0 for even, 1 for odd
            int coursesemval = c.getSemester() % 2; // 0 for even, 1 for odd

            if (currentsemval == coursesemval) {
                if (getGradePoints(courseGrades.get(c)) <= getGradePoints("D")) {
                } else {
                    System.out.println("Course already completed with a sufficient grade.");
                    return false;
                }
            } else {
                System.out.println("Course not available for this semester.");
                return false;
            }
        } else {
            System.out.println("Course not available for this semester.");
            return false;
        }

        for (String prerequisiteCode : c.getPrerequisites()) {
            course prerequisite = coursecatalog.findCourseByCode(prerequisiteCode);
            if (prerequisite == null || !completedcourses.contains(prerequisite)) {
                System.out.println("Prerequisite not met for course: " + c.getcode());
                return false;
            }
        }

        int currentCredits = 0;
        for (course rc : currentcourses) {
            currentCredits += rc.getCredits();

            if (currentCredits + rc.getCredits() > creditl) {
                System.out.println("Credit limit exceeded.");
                return false;
            }
        }

        try {
            c.addStudent(this);
            currentcourses.add(c);
            registrationTime.put(c, System.currentTimeMillis());
            System.out.println("Successfully registered for course: " + c.getcode());
            return true;
        } catch (CourseFull e) {
            return false;
        }
    }



    public void updateSGPA() {
        double sgpa = calculateSGPA(semester);
        semesterSGPA.put(semester, sgpa);
        System.out.println("SGPA for semester " + semester + " updated: " + sgpa);
    }

    public double calculateSGPA(int semester) {
        double totalPoints = 0;
        int totalCredits = 0;

        for (course c : completedcourses) {
            if (c.getSemester() == semester && courseGrades.containsKey(c)) {
                double gradePoints = getGradePoints(courseGrades.get(c));
                int cred = c.getCredits();
                totalPoints += gradePoints*cred;
                totalCredits+=cred;
            }
        }

        return (totalCredits > 0) ? totalPoints / totalCredits : 0;
    }


    public double calculateCGPA() {
        double totalSGPA = 0;
        int totalSemesters = semesterSGPA.size();

        // Sum all SGPAs
        for (double sgpa : semesterSGPA.values()) {
            totalSGPA += sgpa;
        }

        return (totalSemesters > 0) ? totalSGPA / totalSemesters : 0;
    }
    private double getGradePoints(String grade) {
        switch (grade) {
            case "A": return 10.0;
            case "A-": return 9.0;
            case "B": return 8.0;
            case "B-": return 7.0;
            case "C": return 6.0;
            case "D": return 5.0;
            case "F": return 0.0;
            default: return 0.0;
        }
    }

    public void trackAcademicProgress() {
        System.out.println("Tracking Academic Progress:");
        System.out.println("Current Semester: " + semester);

        System.out.println("\nCurrent Courses:");
        for (course c : currentcourses) {
            System.out.println(c.getcode() + ": " + c.getTitle());
        }

        System.out.println("\nCompleted Courses:");
        for (course c : completedcourses) {
            System.out.println(c.getcode() + ": " + c.getTitle() + " (Grade: " + courseGrades.get(c) + ")");
        }

        System.out.println("\nSGPA by Semester:");
        for (Map.Entry<Integer, Double> entry : semesterSGPA.entrySet()) {
            System.out.println("Semester " + entry.getKey() + ": SGPA = " + entry.getValue());
        }

        System.out.println("\nUpdated CGPA: " + calculateCGPA());
    }

    private boolean isSemesterComplete() {
        if (currentcourses.isEmpty()) {
            return true;
        }
        return false;
    }

    public void startNextSemester() {
        if (isSemesterComplete()) {
            updateSGPA();
            calculateCGPA();

            semester++;
            System.out.println("Moved to semester " + semester);
        } else {
            System.out.println("Not all grades are assigned yet. Please complete all courses.");
        }
    }

    public void dropCourse(String courseCode)  throws DropDeadlinePassed {
        course courseToDrop = coursecatalog.findCourseByCode(courseCode);

        if (courseToDrop != null && currentcourses.contains(courseToDrop)) {

            long registrationTimeMillis = registrationTime.get(courseToDrop);
            long currentTimeMillis = System.currentTimeMillis();
            long timeElapsed = currentTimeMillis - registrationTimeMillis;

            if (timeElapsed > 300000) { // 5 minutes in milliseconds
                throw new DropDeadlinePassed("Cannot drop course: " + courseToDrop.getcode() + ". The drop deadline has passed.");
            }
            int creditsBeforeDrop = currentcourses.stream().mapToInt(course::getCredits).sum();

            currentcourses.remove(courseToDrop);
            courseGrades.remove(courseToDrop);

            int creditsAfterDrop = currentcourses.stream().mapToInt(course::getCredits).sum();

            System.out.println("Course dropped: " + courseToDrop.getcode());
            System.out.println("Credits before drop: " + creditsBeforeDrop);
            System.out.println("Credits after drop: " + creditsAfterDrop);
        } else {
            System.out.println("Course not found in current courses.");
        }
    }

    public void submitComplaint(String description) {
        complaint newComplaint = new complaint(description);
        complaints.add(newComplaint);
        manager.getInstance().addComplaint(newComplaint);
        System.out.println("Complaint submitted:");
        newComplaint.displayComplaintDetails();
    }

    public void viewComplaints() {
        System.out.println("Your complaints:");
        for (complaint complaint : complaints) {
            complaint.displayComplaintDetails();
        }
    }

    public void printAllCoursesWithGrades() {
        System.out.println("Courses and Grades till Semester " + semester + ":");
        for (course c : completedcourses) {
            if (c.getSemester() < semester) {
                System.out.println("Course Code: " + c.getcode() + ", Title: " + c.getTitle() +
                        ", Grade: " + courseGrades.get(c) + ", Semester: " + c.getSemester());
                System.out.println();
            }
        }
    }


    public int getrollNo() {
        return rollno;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getSemester() {
        return semester;
    }

    public void setrollNo(int rollno) {
        this.rollno = rollno;
    }

    protected void updateName(String newName) {
        this.name = newName;
        System.out.println("Student's name updated to: " + this.name);
    }

    protected void updateRollNumber(int rollnumber) {
        this.rollno = rollnumber;
        System.out.println("Student's roll number updated to: " + this.rollno);
    }

    // Method to update the student's email
    protected void updateEmail(String newEmail) {
        this.email = newEmail;
        System.out.println("Student's email updated to: " + this.email);
    }

    public void updateGrade(String courseCode, String newGrade) {
        course targetCourse = null;

        for (course c : currentcourses) {
            if (c.getcode().equals(courseCode)) {
                targetCourse = c;
                break;
            }
        }

        if (targetCourse != null) {
            courseGrades.put(targetCourse, newGrade);
            System.out.println("Grade updated for course: " + courseCode);

            currentcourses.remove(targetCourse);
            completedcourses.add(targetCourse);
            System.out.println("Course " + courseCode + " moved to completed courses.");
        } else {
            System.out.println("Course not found in current courses.");
        }
    }


    public void printCompletedCourses() {
        System.out.println("Completed Courses:");
        if (completedcourses.isEmpty()) {
            System.out.println("No completed courses available.");
        } else {
            for (course c : completedcourses) {
                System.out.println(c.getcode() + ": " + c.getTitle() + " (Grade: " + courseGrades.get(c) + ")");
            }
        }
    }

    public List<course> getCurrentCourses() {
        return currentcourses;
    }

    public Map<course, String> getCourseGrades() {
        return courseGrades;
    }

    private course findCourseByCode(String code) {
        return coursecatalog.findCourseByCode(code);
    }


    public void applyForTAPosition(String selectedCourseCode) {

        course selectedCourse = findCourseByCode(selectedCourseCode);
        if (isCourseCompleted(selectedCourseCode)) {
            if (isEligibleForTAPosition(selectedCourse)) {
                selectedCourse.ApplyforTA(this);
                System.out.println("Successfully applied for TA position for course: " + selectedCourse.getcode());
            } else {
                System.out.println("You are not eligible to apply for TA position for this course.");
            }
        } else {
            System.out.println("You cannot apply for a TA position because you have not completed this course.");
        }
    }


    private boolean isEligibleForTAPosition(course c) {
        String grade = courseGrades.get(c);
        return grade != null && (grade.equals("A") || grade.equals("A-"));
    }

    public boolean isCourseCompleted(String courseCode) {
        for (course c : completedcourses) {
            if (c.getcode().equals(courseCode)) {
                return true;
            }
        }
        return false;
    }


    public void giveFeedback(course course, feedback<?> fb) {
        course.addFeedback(fb);
        System.out.println("Feedback submitted successfully!");
    }

    public String getpassword() {
        return password;
    }

    public String toString() {
        StringBuilder studentDetails = new StringBuilder();
        studentDetails.append("Student Name: ").append(this.name).append("\n");
        studentDetails.append("Email: ").append(this.email).append("\n");
        studentDetails.append("Semester: ").append(this.semester).append("\n");
        studentDetails.append("Roll Number: ").append(this.rollno).append("\n");
        return studentDetails.toString();
    }



}
