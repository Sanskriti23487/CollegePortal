import java.util.*;
public class tassistant extends student {

    private course assignedCourse;

    public tassistant(String name, String email, String password, int rollno, course assignedCourse) {
        super(name, email, password, rollno);
        this.assignedCourse = assignedCourse;
    }

    public course getAssignedCourse() {
        return assignedCourse;
    }

    public void setAssignedCourse(course assignedCourse) {
        this.assignedCourse = assignedCourse;
    }

    public void viewEnrolledStudents() {
        System.out.println("Enrolled Students for course: " + assignedCourse.getcode());
        Map<student, String> enrolledStudents = assignedCourse.getEnrolledStudents();

        if (enrolledStudents.isEmpty()) {
            System.out.println("No students are enrolled in this course.");
        } else {
            for (student s : enrolledStudents.keySet()) {
                String grade = enrolledStudents.get(s) == null ? "No grade assigned yet" : enrolledStudents.get(s);
                System.out.println("Student: " + s.getname() + " (Roll No: " + s.getrollNo() + "), Grade: " + grade);
            }
        }
    }

    private int compareGrades(String grade1, String grade2) {
        List<String> gradeOrder = List.of("null", "F", "D", "C", "B-", "B+", "A-", "A");

        String g1 = (grade1 != null) ? grade1 : "null";
        String g2 = (grade2 != null) ? grade2 : "null";

        return Integer.compare(gradeOrder.indexOf(g1), gradeOrder.indexOf(g2));
    }

    public void improveStudentGrade(int rollNo) {
        Map<student, String> enrolledStudents = assignedCourse.getEnrolledStudents();

        student stu = null;
        for (student s : enrolledStudents.keySet()) {
            if (s.getrollNo() == rollNo) {
                stu = s;
                break;
            }
        }

        if (stu != null) {
            String currentGrade = enrolledStudents.get(stu);
            String nextGrade = getNextHigherGrade(currentGrade);

            if (nextGrade != null) {
                assignedCourse.setGradeForStudent(stu, nextGrade);
                System.out.println("Grade for student with roll number " + rollNo + " improved to: " + nextGrade);
            } else {
                System.out.println("The grade is already at the maximum (A).");
            }
        } else {
            System.out.println("Student not found in this course.");
        }
    }


    private String getNextHigherGrade(String currentGrade) {
        List<String> gradeOrder = List.of("null", "F", "D", "C", "B-", "B", "A-", "A");
        int currentIndex = (currentGrade != null) ? gradeOrder.indexOf(currentGrade) : -1;

        if (currentIndex < gradeOrder.size() - 1) {
            return gradeOrder.get(currentIndex + 1);
        } else {
            return null;
        }
    }


    public String toString() {
        StringBuilder taDetails = new StringBuilder(super.toString());
        taDetails.append("Assigned Course: ").append(this.assignedCourse.getcode()).append("\n");
        return taDetails.toString();
    }
}
