import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class coursecatalog {
    private static final List<course> catalog = new ArrayList<>();

    public static void addCourse(course c) {
        catalog.add(c);
    }

    public static void removeCourse(String courseCode) {
        catalog.removeIf(c -> c.getcode().equals(courseCode));
    }


    public static List<course> getAllCourses() {
        return new ArrayList<>(catalog); // Return a copy of the list
    }

    public static course findCourseByCode(String courseCode) {
        for (course c : catalog) {
            if (c.getcode().equals(courseCode)) {
                return c;
            }
        }
        return null;
    }

    public static void initializeCourseCatalog() {
        coursecatalog.addCourse(new course("CS101", "Introduction to Computer Science", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS102", "Data Structures", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS103", "Introduction to Programming", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS104", "Discrete Mathematics", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS105", "Digital Logic Design", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS106", "Computer Organisation", Arrays.asList(), 1));
        coursecatalog.addCourse(new course("CS201", "Algorithms", Arrays.asList("CS102"), 2));
        coursecatalog.addCourse(new course("CS202", "Operating Systems", Arrays.asList(), 2));
        coursecatalog.addCourse(new course("CS301", "Database Systems", Arrays.asList("CS201"), 3));
        coursecatalog.addCourse(new course("CS302", "Computer Networks", Arrays.asList("CS202"), 3));
        coursecatalog.addCourse(new course("CS401", "Software Engineering", Arrays.asList("CS201", "CS202"), 4));
        coursecatalog.addCourse(new course("CS402", "Artificial Intelligence", Arrays.asList("CS201"), 4));
        coursecatalog.addCourse(new course("C501", "Machine Learning", Arrays.asList("CS303"), 5));
        coursecatalog.addCourse(new course("CS502", "Cybersecurity", Arrays.asList("CS202"), 5));
        coursecatalog.addCourse(new course("Cs601", "Human-Computer Interaction", Arrays.asList("CS303"), 6));
        coursecatalog.addCourse(new course("CS602", "Cloud Computing", Arrays.asList("CS301"), 6));
        coursecatalog.addCourse(new course("CS701", "Computer Vision", Arrays.asList("CS304"), 7));
        coursecatalog.addCourse(new course("CS702", "Big Data", Arrays.asList("CS301"), 7));
        coursecatalog.addCourse(new course("CS801", "Quantum Computing", Arrays.asList("CS304"), 8));
        coursecatalog.addCourse(new course("CS802", "Blockchain Technology", Arrays.asList("CS402"), 8));
    }

}
