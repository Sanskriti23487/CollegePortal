import java.util.HashMap;
import java.util.Map;

public class manager {
    private static manager instance;
    private Map<Integer, complaint> complaints = new HashMap<>();

    private manager() { }

    public static manager getInstance() {
        if (instance == null) {
            instance = new manager();
        }
        return instance;
    }

    public void addComplaint(complaint comp) {
        complaints.put(comp.getId(), comp);
    }

    public complaint findComplaintById(int id) {
        return complaints.get(id);
    }

    public Map<Integer, complaint> getAllComplaints() {
        return complaints;
    }
}
