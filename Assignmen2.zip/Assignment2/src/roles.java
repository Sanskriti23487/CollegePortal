public enum roles {
    Student, Professor, Admin;
}
