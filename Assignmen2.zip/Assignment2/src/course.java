import java.util.*;

public class course {
    private String code;
    private String title;
    private String professor;
    private int credits;
    private List<String> prerequisites;
    private int semester;
    private schedule courseSchedule;
    private String syllabus;
    private int enrollmentLimit;
    private String officeHours;
    private tassistant assignedTA;

    private Map<student, String> enrolledStudents;
    private List<student> taApplications;
    private List<feedback<?>> feedbackList;

    public course(String courseCode, String title, List<String> prerequisites, int semester) {
        this.code = courseCode;
        this.title = title;
        this.professor = null;
        this.credits = 4;
        this.prerequisites = prerequisites;
        this.semester = semester;
        this.enrollmentLimit = 30; // Default value
        this.officeHours = "TBD"; // Default value
        this.enrolledStudents = new HashMap<>();
        this.syllabus=syllabus;
        this.taApplications = new ArrayList<>();
        this.feedbackList= new ArrayList<>();
    }


    public String getcode() {
        return code;
    }

    public void setcode(String courseCode) {
        this.code = courseCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public List<String> getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(List<String> prerequisites) {
        this.prerequisites = prerequisites;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }


    public void addStudent(student s) throws CourseFull {
        if (enrolledStudents.size() < enrollmentLimit) {
            enrolledStudents.put(s, null);
        } else {
            throw new CourseFull("Enrollment limit reached for course: " + code);
        }
    }

    public String getGradeForStudent(student s) {
        return enrolledStudents.get(s);
    }

    public void setGradeForStudent(student s, String grade) {
        enrolledStudents.put(s, grade);
    }

    public void removeStudent(student student) {
        enrolledStudents.remove(student);
    }

    public void printschedule() {
        System.out.println(courseSchedule);
    }

    public void setCourseSchedule(schedule courseSchedule) {
        this.courseSchedule = courseSchedule;
    }

    public String getSyllabus() {
        return syllabus;
    }

    public void setSyllabus(String syllabus) {
        this.syllabus = syllabus;
    }

    public int getEnrollmentLimit() {
        return enrollmentLimit;
    }

    public void setEnrollmentLimit(int enrollmentLimit) {
        this.enrollmentLimit = enrollmentLimit;
    }

    public String getOfficeHours() {
        return officeHours;
    }

    public void setOfficeHours(String officeHours) {
        this.officeHours = officeHours;
    }

    public Map<student, String> getEnrolledStudents() {
        return enrolledStudents;
    }

    public tassistant getAssignedTA() {
        return assignedTA;
    }

    public void setAssignedTA(tassistant ta) {
        this.assignedTA = ta;
        System.out.println("TA " + ta.getname() + " has been assigned to course: " + this.code);
    }


    public void ApplyforTA(student applicant) {
        taApplications.add(applicant);
    }

    public List<student> getTAApplications() {
        return taApplications;
    }

    public void addFeedback(feedback<?> fb) {
        feedbackList.add(fb);
    }

    // Method to display all feedbacks for the course
    public void displayFeedbacks() {
        System.out.println("Feedbacks for course: " + code);
        for (feedback<?> fb : feedbackList) {
            fb.displayFeedback();
        }
    }

    public void displayCourseDetails() {
        System.out.println("Course Code: " + code + ", Title: " + title + ", Professor: " + professor +
                ", Credits: " + credits + ", Semester offered: " + semester);
    }





    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Course Code: ").append(code).append("\n")
                .append("Title: ").append(title).append("\n")
                .append("Professor: ").append(professor != null ? professor : "Not Assigned").append("\n")
                .append("Credits: ").append(credits).append("\n")
                .append("Semester: ").append(semester).append("\n")
                .append("Prerequisites: ").append(prerequisites != null ? (prerequisites.isEmpty() ? "None" : String.join(", ", prerequisites)) : "null").append("\n")
                .append("Enrollment Limit: ").append(enrollmentLimit).append("\n")
                .append("Office Hours: ").append(officeHours).append("\n")
                .append("Syllabus: ").append(syllabus != null ? syllabus : "TBD");

        return sb.toString();
    }

}
