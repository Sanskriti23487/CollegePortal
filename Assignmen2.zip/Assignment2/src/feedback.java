public class feedback<T> {
    private T feedback;

    public feedback(T feedback) {
        this.feedback = feedback;
    }

    public T getFeedback() {
        return feedback;
    }

    public void displayFeedback() {
        System.out.println("Feedback: " + feedback.toString());
        System.out.println("----------------");
    }
}
