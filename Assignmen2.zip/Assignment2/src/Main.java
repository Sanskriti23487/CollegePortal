import java.util.*;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    private static List<student> students = new ArrayList<>();
    private static List<professor> professors = new ArrayList<>();
    public static List<tassistant> teachingAssistants = new ArrayList<>();
    private static admin adminAcc = admin.getInstance("Admin", "admin@uni.ac.in", "admin123", professors, students);


    public static void main(String[] args) {

        coursecatalog.initializeCourseCatalog();
        students.add(new student("Sanskriti", "sanskriti@uni.ac.in", "password1", 101));
        students.add(new student("a", "a.in", "abc", 000));
        students.add(new student("Shubhi", "shubhi@uni.ac.in", "password2", 102));
        students.add(new student("Saanvi", "saanvi@uni.ac.in", "password3", 103));
        students.add(new student("Riya", "riya@uni.ac.in", "password4", 104));
        students.add(new student("Purvi", "purvi@uni.ac.in", "password5", 105));
        students.add(new student("Rishi", "rishi@uni.ac.in", "password6", 106));
        students.add(new student("Mayank", "mayank@uni.ac.in", "password7", 107));


        professors.add(new professor("b", "b.in", "abc"));
        professors.add(new professor("Mango", "mango@uni.ac.in", "profpassword1"));
        professors.add(new professor("Banana", "banana@uni.ac.in", "profpassword2"));
        professors.add(new professor("Orange", "orange@uni.ac.in", "profpassword3"));
        professors.add(new professor("Litchi", "litchi@uni.ac.in", "profpassword4"));
        professors.add(new professor("Grapes", "grapes@uni.ac.in", "profpassword5"));
        professors.add(new professor("Apple", "apple@uni.ac.in", "profpassword6"));

        System.out.println("Welcome to the University Course Registration System");
        System.out.println("1. Enter the Application");
        System.out.println("2. Exit the Application");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                showLoginMenu();
                break;
            case 2:
                System.out.println("Exiting the Application. Goodbye!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");

        }
    }

    public static void showLoginMenu() {
        System.out.println("Login as:");
        System.out.println("1. Student");
        System.out.println("2. Professor");
        System.out.println("3. Teaching Assistant");
        System.out.println("4. Administrator");
        System.out.println("5. Exit now");

        int role = scanner.nextInt();
        scanner.nextLine();

        switch (role) {
            case 1:
                loginStudent();
                break;
            case 2:
                loginProfessor();
                break;
            case 3:
                loginTA();
                break;
            case 4:
                loginAdmin();
                break;
            case 5:
                System.out.println("Exiting the Application. Goodbye!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    public static void loginStudent() {
        System.out.println("Enter Student Email: ");
        String email = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();

        student existingStudent = findStudentByEmail(email);

        try {
            if (existingStudent != null) {
                if (existingStudent.login(email, password)) {
                    System.out.println("Student login successful.");
                    showStudentMenu(existingStudent);
                }
            } else {
                throw new InvalidLogin("InvalidLogin:Student not found.");
            }
        } catch (InvalidLogin e) {
            System.out.println(e.getMessage());
            System.out.println("Do you want to sign up? (y/n)");
            String signUpChoice = scanner.nextLine();

            if (signUpChoice.equalsIgnoreCase("y")) {
                signUpStudent();
            } else {
                showLoginMenu();
            }
        }
    }



    private static void signUpStudent() {
        System.out.println("Enter your name: ");
        String name = scanner.nextLine();
        System.out.println("Enter your email: ");
        String email = scanner.nextLine();
        System.out.println("Enter your password: ");
        String password = scanner.nextLine();
        System.out.println("Enter your roll number: ");
        int rollNo = scanner.nextInt();
        scanner.nextLine();

        student newStudent = new student(name, email, password, rollNo);
        students.add(newStudent);
        newStudent.signin(name, email, password);
        System.out.println("Signup successful. You can now log in.");
        loginStudent();
    }


    private static student findStudentByEmail(String email) {
        for (student student : students) {
            if (student.getemail().equals(email)) {
                return student;
            }
        }
        return null;
    }




    public static void loginProfessor() {
        System.out.println("Enter Professor Email: ");
        String email = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();

        professor existingProf = findProfbyemail(email);

        try {
            if (existingProf != null) {
                if (existingProf.login(email, password)) {
                    System.out.println("Professor login successful.");
                    showProfessorMenu(existingProf);
                }
            } else {
                throw new InvalidLogin("InvalidLogin:Professor not found.");
            }
        } catch (InvalidLogin e) {
            System.out.println(e.getMessage());
            System.out.println("Do you want to sign up? (y/n)");
            String signUpChoice = scanner.nextLine();

            if (signUpChoice.equalsIgnoreCase("y")) {
                signUpProfessor();
            } else {
                showLoginMenu();
            }
        }
    }


    private static void signUpProfessor() {
        System.out.println("Enter your name: ");
        String name = scanner.nextLine();
        System.out.println("Enter your email: ");
        String email = scanner.nextLine();
        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        professor newProfessor = new professor(name, email, password);
        professors.add(newProfessor);
        newProfessor.signin(name, email, password);
        System.out.println("Signup successful. You can now log in.");
        loginProfessor();
    }


    private static professor findProfbyemail(String email) {
        for (professor prof : professors) {
            if (prof.getemail().equals(email)) {
                return prof;
            }
        }
        return null;
    }


    public static void loginTA() {
        System.out.println("Enter TA Email: ");
        String email = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();

        tassistant existingTA = findTAByEmail(email);

        try {
            if (existingTA != null) {
                if (existingTA.login(email, password)) {
                    System.out.println("TA login successful.");
                    showTAMenu(existingTA);
                }
            } else {
                throw new InvalidLogin("InvalidLogin:TA not found.");
            }
        } catch (InvalidLogin e) {
            System.out.println(e.getMessage());
            showLoginMenu();
        }
    }



    private static tassistant findTAByEmail(String email) {
        for (tassistant ta : teachingAssistants) {
            if (ta.getemail().equals(email)) {
                return ta;
            }
        }
        return null;
    }

    public static void loginAdmin() {
        System.out.println("Enter Admin Email: ");
        String email = scanner.nextLine();
        System.out.println("Enter Password: ");
        String password = scanner.nextLine();

        if (adminAcc.getemail().equals(email) && adminAcc.checkpass(password)) {
            System.out.println("Admin login successful.");
            showAdminmenu(adminAcc);
        } else {
            System.out.println("Invalid email or password. Please try again.");
        }
    }

    public static void showStudentMenu(student currentStudent) {
        boolean running = true;
        System.out.println(currentStudent.toString());
        System.out.println();
        while (running) {
            System.out.println("\nStudent Menu:");
            System.out.println("1. View Available Courses");
            System.out.println("2. View Schedule");
            System.out.println("3. Register for a Course");
            System.out.println("4. Drop a Course");
            System.out.println("5. Submit a Complaint");
            System.out.println("6. View Complaints");
            System.out.println("7. Print All Courses with Grades");
            System.out.println("8. Track Academic Progress");
            System.out.println("9. Apply for TA Position");
            System.out.println("10. Give Feedback to Courses");
            System.out.println("11. Logout");


            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    currentStudent.viewAvailableCourses();
                    break;
                case 2:
                    currentStudent.viewSchedule();
                    break;

                case 3:
                    String a = "y";
                    while (a.equals("y")) {
                        System.out.println("Enter course code to register: ");
                        String code = scanner.nextLine();
                        try {
                            currentStudent.registerCourse(code);
                            course c = coursecatalog.findCourseByCode(code);
                            c.addStudent(currentStudent);
                        } catch (CourseFull e) {
                            System.out.println(e.getMessage());
                        }
                        System.out.println("Wish to add more courses? (y/n): ");
                        a = scanner.nextLine();
                    }
                    break;

                case 4:
                    String b = "y";
                    while (b.equals("y")) {
                        System.out.println("Enter course code to drop: ");
                        String code = scanner.nextLine();
                        try {
                            currentStudent.dropCourse(code);
                            course c = coursecatalog.findCourseByCode(code);
                            c.removeStudent(currentStudent);
                        } catch (DropDeadlinePassed e) {
                            System.out.println("Cannot drop course: " + e.getMessage());
                        }
                        System.out.println("Wish to drop more courses? (y/n): ");
                        b = scanner.nextLine();
                    }
                    break;

                case 5:
                    System.out.println("Describe your issue: ");
                    String details = scanner.nextLine();
                    currentStudent.submitComplaint(details);
                    break;
                case 6:
                    currentStudent.viewComplaints();
                    break;
                case 7:
                    currentStudent.printAllCoursesWithGrades();
                    break;
                case 8:
                    currentStudent.trackAcademicProgress();
                    break;

                case 9:
                    currentStudent.printCompletedCourses();
                    System.out.println("Enter the course code to apply for TA position: ");
                    String courseCode = scanner.nextLine();
                    currentStudent.applyForTAPosition(courseCode);
                    break;

                case 10:
                    currentStudent.printCompletedCourses();
                    System.out.println("Enter the course code you want to give feedback for: ");
                    String ccode = scanner.nextLine();

                    if (currentStudent.isCourseCompleted(ccode)) {
                        course courseForFeedback = coursecatalog.findCourseByCode(ccode);

                        if (courseForFeedback != null) {
                            System.out.println("Give numeric feedback (1) or textual feedback (2): ");
                            int feedbackChoice = scanner.nextInt();
                            scanner.nextLine();

                            feedback<?> fb = null;

                            if (feedbackChoice == 1) {
                                System.out.println("Enter numeric rating (1-5): ");
                                int rating = scanner.nextInt();
                                fb = new feedback<>(rating);  // Numeric feedback
                            } else if (feedbackChoice == 2) {
                                System.out.println("Enter your textual feedback: ");
                                String textFeedback = scanner.nextLine();
                                fb = new feedback<>(textFeedback);  // Textual feedback
                            }

                            if (fb != null) {
                                currentStudent.giveFeedback(courseForFeedback, fb);
                            } else {
                                System.out.println("Invalid feedback input.");
                            }
                        } else {
                            System.out.println("Course not found.");
                        }
                    } else {
                        System.out.println("You can only give feedback for completed courses.");
                    }
                    break;



                case 11:
                    currentStudent.logout();
                    running = false;
                    showLoginMenu();
                    break;


                default:
                    System.out.println("Invalid choice. Please try again.");


            }
        }
    }

    public static void showProfessorMenu(professor currentProfessor){
        boolean running = true;
        Scanner scanner = new Scanner(System.in);

        while (running) {
            System.out.println("\nProfessor Menu:");
            System.out.println("1. View Assigned Courses");
            System.out.println("2. View Enrolled Students");
            System.out.println("3. Update Course Details");
            System.out.println("4. Assign TA");
            System.out.println("5. View Course Feedback");
            System.out.println("6. Logout");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    currentProfessor.viewAssignedCourses();
                    break;

                case 2:
                    currentProfessor.viewEnrolledStudents();
                    break;



                case 3:
                    currentProfessor.viewAssignedCourses();
                    System.out.println("Enter Course Code to Update: ");
                    String courseCode = scanner.nextLine();
                    course selectedCourse = coursecatalog.findCourseByCode(courseCode);
                    Map<Integer, String> assignedCourses = currentProfessor.getSemesterCourses();
                    for (String assignedCourseCode : assignedCourses.values()) {
                        if (assignedCourseCode.equals(courseCode)) {


                            System.out.println("Enter new schedule details:");
                            System.out.println("Enter day of the week (e.g., Monday): ");
                            String day = scanner.nextLine();
                            System.out.println("Enter start hour (24-hour format): ");
                            int startHour = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Enter location of the class: ");
                            String location = scanner.nextLine();

                            schedule newSchedule = new schedule(startHour, day, location);

                            System.out.println("Enter new syllabus: ");
                            String syllabus = scanner.nextLine();
                            System.out.println("Enter new enrollment limit: ");
                            int enrollmentLimit = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Enter new office hours: ");
                            String officeHours = scanner.nextLine();

                            int credits;

                            System.out.println("Enter new number of credits (2 or 4): ");
                            credits = scanner.nextInt();

                            while (credits != 2 && credits != 4) {
                                System.out.println("Invalid input. Please enter either 2 or 4: ");
                                credits = scanner.nextInt();
                            }

                            currentProfessor.updateCourseDetails(selectedCourse, newSchedule, syllabus, enrollmentLimit, officeHours, credits);
                            System.out.println(selectedCourse.toString());
                        } else {
                            System.out.println("Professor is not assigned this course.");
                        }
                    }

                    break;

                case 4:
                    System.out.println("Enter Course Code to Assign TA: ");
                    String taCourseCode = scanner.nextLine();
                    course taSelectedCourse = coursecatalog.findCourseByCode(taCourseCode);

                    boolean isTAAssignedCourse = false;
                    for (String assignedCourseCode : currentProfessor.getSemesterCourses().values()) {
                        if (assignedCourseCode.equals(taCourseCode)) {
                            isTAAssignedCourse = true;
                            break;
                        }
                    }

                    if (isTAAssignedCourse) {
                        List<student> taApplications = taSelectedCourse.getTAApplications();

                        if (taApplications.isEmpty()) {
                            System.out.println("No TA applications for course: " + taSelectedCourse.getcode());
                        } else {
                            System.out.println("TA Applications for course: " + taSelectedCourse.getcode());
                            for (student s : taApplications) {
                                System.out.println("Student Roll Number: " + s.getrollNo() + ", Name: " + s.getname());
                            }

                            System.out.println("Enter the Roll Number of the student to assign as TA: ");
                            int rollNo = scanner.nextInt();
                            scanner.nextLine();

                            student selectedTA = null;
                            for (student s : taApplications) {
                                if (s.getrollNo() == rollNo) {
                                    selectedTA = s;
                                    break;
                                }
                            }

                            if (selectedTA != null) {
                                currentProfessor.assignTA(taSelectedCourse, selectedTA);
                            } else {
                                System.out.println("No student found with roll number: " + rollNo);
                            }
                        }
                    } else {
                        System.out.println("You are not assigned to this course.");
                    }
                    break;


                case 5:
                    currentProfessor.viewAssignedCourses();
                    System.out.println("Enter Course Code to View Feedback: ");
                    String feedbackCourseCode = scanner.nextLine();
                    course feedbackCourse = coursecatalog.findCourseByCode(feedbackCourseCode);

                    if (feedbackCourse != null && currentProfessor.getSemesterCourses().containsValue(feedbackCourseCode)) {
                        currentProfessor.viewCourseFeedback(feedbackCourse);
                    } else {
                        System.out.println("Course not found or not assigned to you.");
                    }
                    break;



                case 6:
                    currentProfessor.logout();
                    running = false;
                    showLoginMenu();
                    break;


                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void showTAMenu(tassistant currentTA){

        boolean exit = false;

        while (!exit) {
            System.out.println("------ TA Menu ------");
            System.out.println("1. View Enrolled Students");
            System.out.println("2. Improve Student Grade");
            System.out.println("3. Logout");
            System.out.print("Please select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    currentTA.viewEnrolledStudents();
                    break;
                case 2:

                    System.out.print("Enter Student Roll Number: ");
                    int rollNo = scanner.nextInt();
                    scanner.nextLine();
                    currentTA.improveStudentGrade(rollNo);
                    break;
                case 3:
                    exit = true;
                    System.out.println("Logged out successfully.");
                    showLoginMenu();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

    }

    public static void showAdminmenu(admin currentadmin) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add Course");
            System.out.println("2. Remove Course");
            System.out.println("3. View Course Catalog");
            System.out.println("4. Assign Professor to Course");
            System.out.println("5. View Complaints");
            System.out.println("6. Update Complaint Status");
            System.out.println("7. View Student Records");
            System.out.println("8. Update Student records");
            System.out.println("9. Update Student Grade");
            System.out.println("10. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Course Code: ");
                    String courseCode = scanner.nextLine();
                    System.out.print("Enter Course Title: ");
                    String courseTitle = scanner.nextLine();
                    System.out.print("Enter Semester: ");
                    int semester = scanner.nextInt();
                    scanner.nextLine();

                    List<String> prerequisites = new ArrayList<>();
                    System.out.print("Enter the number of prerequisites (enter 0 if none): ");
                    int numPrerequisites = scanner.nextInt();
                    scanner.nextLine();

                    for (int i = 0; i < numPrerequisites; i++) {
                        System.out.print("Enter prerequisite course code #" + (i + 1) + ": ");
                        String prerequisiteCode = scanner.nextLine();
                        prerequisites.add(prerequisiteCode);
                    }


                    System.out.print("Assign Professor (name): ");
                    String professorName = scanner.nextLine();
                    professor prof = adminAcc.findProfessorByName(professorName);

                    if (prof == null) {
                        System.out.println("Professor not found!");
                    } else {
                        course newCourse = new course(courseCode, courseTitle, prerequisites, semester);
                        adminAcc.addCourse(newCourse);
                    }
                    break;


                case 2:
                    System.out.print("Enter Course Code to Remove: ");
                    String removeCourseCode = scanner.nextLine();
                    adminAcc.removeCourse(removeCourseCode);
                    break;

                case 3:
                    adminAcc.viewCourseCatalog();
                    break;


                case 4:
                    System.out.print("Enter Course Code: ");
                    String assignCourseCode = scanner.nextLine();
                    System.out.print("Enter Professor Name: ");
                    String assignProfessorName = scanner.nextLine();
                    course courseToAssign = coursecatalog.findCourseByCode(assignCourseCode);

                    if (courseToAssign != null) {
                        int courseSemester = courseToAssign.getSemester();
                        adminAcc.assignProfessor(assignCourseCode, assignProfessorName, courseSemester);
                    } else {
                        System.out.println("Course not found.");
                    }
                    break;

                case 5:
                    adminAcc.viewComplaints();
                    break;

                case 6:
                    System.out.print("Enter Complaint ID: ");
                    int complaintId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter New Status: ");
                    String newStatus = scanner.nextLine();
                    adminAcc.updateComplaintStatus(complaintId, newStatus);
                    break;


                case 7:
                    System.out.print("Enter Student Roll Number: ");
                    int studentRollNo = scanner.nextInt();
                    List<student> allStudents = adminAcc.getAllStudents();

                    student foundStudent = null;
                    for (student s : allStudents) {
                        if (s.getrollNo() == studentRollNo) {
                            foundStudent = s;
                            break;
                        }
                    }

                    if (foundStudent != null) {
                        adminAcc.viewStudentRecords(foundStudent);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;


                case 8:
                    System.out.print("Enter Student Roll Number: ");
                    int rollNoToUpdate = scanner.nextInt();
                    scanner.nextLine();

                    student target = null;

                    for (student stu : adminAcc.getAllStudents()) {
                        if (stu.getrollNo() == rollNoToUpdate) {
                            target = stu;
                            break;
                        }
                    }

                    if (target != null) {
                        System.out.println(target.toString());
                        System.out.println("Select detail to update: ");
                        System.out.println("1. Update Name");
                        System.out.println("2. Update Roll Number");
                        System.out.println("3. Update Email");
                        int select = scanner.nextInt();
                        scanner.nextLine();

                        switch (select) {
                            case 1:
                                System.out.print("Enter new name: ");
                                String newName = scanner.nextLine();
                                target.updateName(newName);
                                break;
                            case 2:
                                System.out.print("Enter new roll number: ");
                                int newRollNo = scanner.nextInt();
                                target.updateRollNumber(newRollNo);
                                break;
                            case 3:
                                System.out.print("Enter new email: ");
                                String newEmail = scanner.nextLine();
                                target.updateEmail(newEmail);
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;


                case 9:
                    System.out.print("Enter Student Roll Number: ");
                    int rollNo = scanner.nextInt();
                    scanner.nextLine();

                    student targetStudent = null;

                    for (student stu : adminAcc.getAllStudents()) {
                        if (stu.getrollNo() == rollNo) {
                            targetStudent = stu;
                            break;
                        }
                    }

                    if (targetStudent != null) {
                        System.out.println("Current Courses:");
                        for (course c : targetStudent.getCurrentCourses()) {
                            System.out.println(c.getcode() + " - " + c.getTitle());
                        }

                        String updateMore = "y";
                        while (updateMore.equals("y")) {
                            System.out.print("Enter Course Code: ");
                            String gradeCourseCode = scanner.nextLine();

                            course gradeCourse = null;
                            for (course c : targetStudent.getCurrentCourses()) {
                                if (c.getcode().equals(gradeCourseCode)) {
                                    gradeCourse = c;
                                    break;
                                }
                            }

                            if (gradeCourse != null) {
                                System.out.print("Enter New Grade: ");
                                String newGrade = scanner.nextLine();

                                adminAcc.updateStudentGrade(rollNo, gradeCourseCode, newGrade);
                                gradeCourse.setGradeForStudent(targetStudent,newGrade);
                                System.out.println("Grade updated for course: " + gradeCourseCode);
                                System.out.println();

                                boolean allGradesUpdated = true;
                                for (course c : targetStudent.getCurrentCourses()) {
                                    if (!targetStudent.getCourseGrades().containsKey(c)) {
                                        allGradesUpdated = false;
                                        break;
                                    }
                                }

                                if (allGradesUpdated) {
                                    System.out.println("All courses have been graded.");
                                    targetStudent.startNextSemester();
                                    break;
                                } else {
                                    System.out.println("Wish to update more courses? (y/n): ");
                                    updateMore = scanner.nextLine();
                                }
                            } else {
                                System.out.println("Course not found in student's current courses.");
                                break;
                            }
                        }
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;


                case 10:
                    adminAcc.logout();
                    running = false;
                    showLoginMenu();
                    break;


                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

    }
}






