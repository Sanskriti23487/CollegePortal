import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class admin extends user {
    private static admin instance;
    private coursecatalog catalog;
    private Map<Integer, complaint> complaints = new HashMap<>();
    private List<professor> allProfessors;
    private List<student> allStudents;

    private admin(String name, String email, String password, List<professor> professors, List<student> students) {
        super(name, email, password);
        this.catalog = new coursecatalog();
        this.allProfessors = professors;
        this.allStudents = students;
    }

    public static admin getInstance(String name, String email, String password, List<professor> professors, List<student> students) {
        if (instance == null) {
            instance = new admin(name, email, password, professors, students);
        }
        return instance;
    }

    public void login(String email, String password) {
        if (this.email.equals(email) && checkpass(password)) {
            System.out.println("Login successful for admin: " + this.name);
        } else {
            System.out.println("Invalid email or password!");
        }
    }

    public void addCourse(course newCourse) {
        List<course> allCourses = catalog.getAllCourses();

        for (course c : allCourses) {
            if (c.getcode().equals(newCourse.getcode())) {
                System.out.println("Conflict: Course with code " + newCourse.getcode() + " already exists.");
                return;
            }
            if (c.getTitle().equals(newCourse.getTitle())) {
                System.out.println("Conflict: Course with title " + newCourse.getTitle() + " already exists.");
                return;
            }
        }

        catalog.addCourse(newCourse);
        System.out.println("Course added successfully.");
    }

    public void removeCourse(String courseCode) {
        course courseToRemove = catalog.findCourseByCode(courseCode);
        if (courseToRemove != null) {
            if (courseToRemove.getEnrolledStudents().isEmpty()) {
                catalog.removeCourse(courseCode);
                System.out.println("Course removed from catalog: " + courseCode);
            } else {
                System.out.println("Course cannot be removed as students are enrolled.");
            }
        } else {
            System.out.println("Course not found with code: " + courseCode);
        }
    }

    public void viewCourseCatalog() {
        List<course> allCourses = catalog.getAllCourses();
        if (allCourses.isEmpty()) {
            System.out.println("The course catalog is empty.");
        } else {
            System.out.println("Course Catalog:");
            System.out.println("__________________");
            for (course c : allCourses) {
                System.out.println(c.toString());
                System.out.println("__________________");
            }
        }
    }

    public void assignProfessor(String courseCode, String professorName, int semester) {
        course c = catalog.findCourseByCode(courseCode);
        if (c == null) {
            System.out.println("Course not found with code: " + courseCode);
            return;
        }

        professor prof = findProfessorByName(professorName);
        if (prof != null) {
            if (prof.getSemesterCourses().containsKey(semester)) {
                System.out.println("Professor " + professorName + " is already assigned to a course in Semester " + semester);
                return;
            }
        } else {
            System.out.println("Professor not found with name: " + professorName);
            return;
        }

        c.setProfessor(professorName);
        prof.getSemesterCourses().put(semester, courseCode);
        System.out.println("Professor " + professorName + " assigned to course: " + courseCode + " in Semester " + semester);
        c.displayCourseDetails();
    }

    public void updateStudentGrade(int rollNo, String courseCode, String newGrade) {
        student stu = findStudentByRollNo(rollNo);
        if (stu != null) {
            stu.updateGrade(courseCode, newGrade);
            System.out.println("Grade for student with roll number " + rollNo + " updated.");
        } else {
            System.out.println("Student not found.");
        }
    }

    public student findStudentByRollNo(int rollNo) {
        for (student stu : allStudents) {
            if (stu.getrollNo() == rollNo) {
                return stu;
            }
        }
        return null;
    }

    public void viewComplaints() {
        Map<Integer, complaint> allComplaints = manager.getInstance().getAllComplaints();
        if (allComplaints.isEmpty()) {
            System.out.println("No complaints to display.");
        } else {
            System.out.println("All complaints:");
            for (complaint comp : allComplaints.values()) {
                comp.displayComplaintDetails();
                System.out.println("______________________");
            }
        }
    }

    public void updateComplaintStatus(int id, String status) {
        complaint comp = manager.getInstance().findComplaintById(id);
        if (comp != null) {
            comp.setStatus(status);
        } else {
            System.out.println("Complaint not found with ID: " + id);
        }
    }




    private complaint findComplaintById(int id) {
        return complaints.get(id);
    }

    public void viewStudentRecords(student s) {
        System.out.println(s.toString());
    }


    public professor findProfessorByName(String name) {
        for (professor p : allProfessors) {
            if (p.getname().equals(name)) {
                return p;
            }
        }
        return null;
    }

    public void addProfessor(professor p) {
        allProfessors.add(p);
    }

    public List<student> getAllStudents() {
        return allStudents;
    }

    public void logout() {
        System.out.println("Student logged out: " + this.name);
    }

}
