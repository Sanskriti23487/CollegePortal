public class complaint {
    private static int idCounter = 1;

    private int id;
    private String description;
    private String status;

    public complaint(String description) {
        this.id = idCounter++;
        this.description = description;
        this.status = "Pending";
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (status.equals("Pending") || status.equals("Resolved")) {
            this.status = status;
            System.out.println("Complaint status updated to: " + status);
        } else {
            System.out.println("Invalid status. Status can only be 'Pending' or 'Resolved'.");
        }
    }

    public void displayComplaintDetails() {
        System.out.println("Complaint ID: " + id);
        System.out.println("Description: " + description);
        System.out.println("Status: " + status);
    }
}
