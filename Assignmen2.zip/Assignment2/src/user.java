public abstract class user {//base class
    protected String name;
    protected String email;
    protected roles role;
    protected String password;


    public user(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }


    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }


    public void setpassword(String password) {
        this.password = password;
    }


    public void viewprofile() {
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Role: " + role);
    }

    public void logout() {
        System.out.println(name + " has logged out.");
    }


    public boolean checkpass(String password) {
        return this.password.equals(password);
    }


}

