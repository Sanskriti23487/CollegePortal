import java.util.*;



public class professor extends user implements login {
    private Map<Integer, String> semesterCourses;


    public professor(String name, String email, String password) {
        super(name, email, password);
        this.semesterCourses = new HashMap<>();
    }


    public Map<Integer, String> getSemesterCourses() {
        return semesterCourses;
    }

    public void setSemesterCourses(Map<Integer, String> semesterCourses) {
        this.semesterCourses = semesterCourses;
    }

    public void signin(String name, String email, String password) {
        System.out.println("Signing up professor...");
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public boolean login(String email, String password) throws InvalidLogin {
        if (this.email.equals(email) && this.password.equals(password)) {
            return true;
        } else {
            throw new InvalidLogin("Invalid email or password.");
        }
    }




    public void logout() {
        System.out.println("Professor " + this.name + " logged out.");

    }
    public void viewAssignedCourses() {
        System.out.println("Courses assigned to Professor " + this.name + ":");
        for (Map.Entry<Integer, String> entry : semesterCourses.entrySet()) {
            int semester = entry.getKey();
            String courseCode = entry.getValue();
            System.out.println("Semester: " + semester + ", Course Code: " + courseCode);
        }
    }

    public void viewEnrolledStudents() {
        for (String courseCode : semesterCourses.values()) {
            course c = coursecatalog.findCourseByCode(courseCode);
            if (c != null) {
                System.out.println("Course Code: " + c.getcode() + ", Title: " + c.getTitle());
                System.out.println("Enrolled Students:");

                Map<student, String> enrolledStudents = c.getEnrolledStudents();

                if (enrolledStudents.isEmpty()) {
                    System.out.println("No students enrolled.");
                } else {
                    for (student s : enrolledStudents.keySet()) {
                        String grade = enrolledStudents.get(s);
                        System.out.println("Student Roll Number: " + s.getrollNo() + ", Name: " + s.getname() + ", Grade: " + grade);
                    }
                }
            } else {
                System.out.println("Course not found with code: " + courseCode);
            }
        }
    }


    public void updateCourseDetails(course c, schedule newSchedule, String syllabus, int enrollmentLimit, String officeHours, int credits) {
        c.setCourseSchedule(newSchedule);
        c.setSyllabus(syllabus);
        c.setEnrollmentLimit(enrollmentLimit);
        c.setOfficeHours(officeHours);
        c.setCredits(credits);
        System.out.println("Course details updated for course: " + c.getcode());
    }


    public void assignTA(course selectedCourse, student selectedTA) {
        // Check if the course already has a TA assigned
        if (selectedCourse.getAssignedTA() != null) {
            System.out.println("This course already has a TA assigned.");
            return;
        }

        tassistant newTA = new tassistant(selectedTA.getname(), selectedTA.getemail(), selectedTA.getpassword(), selectedTA.getrollNo(), selectedCourse);

        selectedCourse.setAssignedTA(newTA);
        Main.teachingAssistants.add(newTA);
        System.out.println("Assigned TA: " + newTA.getname() + " to course: " + selectedCourse.getcode());

    }

    public void viewCourseFeedback(course course) {
        course.displayFeedbacks();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Professor Name: ").append(this.name).append("\n");
        sb.append("Email: ").append(this.email).append("\n");
        sb.append("Assigned Courses:\n");
        for (Map.Entry<Integer, String> entry : semesterCourses.entrySet()) {
            sb.append("Semester ").append(entry.getKey()).append(": Course Code ").append(entry.getValue()).append("\n");
        }
        return sb.toString();
    }







}
