public class CourseFull extends Exception {
    public CourseFull(String message) {
        super(message);
    }
}
