public interface login {
    void signin(String name, String email, String password);
    boolean login(String email, String password) throws InvalidLogin;
    void logout();
}
