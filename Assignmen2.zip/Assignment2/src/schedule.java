public class schedule {
    private int startHour;
    private String location;
    private String day;

    public schedule(int startHour, String day, String location) {
        this.startHour = startHour;
        this.location = location;
        this.day = day;
    }

    // Getters and Setters
    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getEndHour() {
        return startHour + 1; // End hour is always one hour after start hour
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String toString() {
        return "Schedule: " + day + " from " + startHour + ":00 to " + getEndHour() + ":00, Location: " + location;
    }
}
